<?php
//You can either use it in html, but it's better like this and use include because when you use it in html, it's very hasle and time wasting to do so.
$conn = mysqli_connect("localhost","root","","chat_data");
//Localhost - the php, root - username to log in php, password - password you use it in your php, database - the database you created.
?>
