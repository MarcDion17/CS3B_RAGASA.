<?php
  session_start();
  include_once "php_files/config.php";
  if (!isset($_SESSION["unique_id"])) {
    header("location: /sign_in_chat.php");
  } else {
    $log_id = $_SESSION['unique_id'];
    $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE unique_id = $log_id")); //Fetch if the user login
  }
  ?>